package test

import (
	"github.com/spf13/cobra"
	"go-api/app/model"
	"go-api/common/database"
	"go-api/common/global"
	"go-api/pkg/logger"
	"go-api/tools"
	"go-api/tools/config"
	"gorm.io/gorm"
	"time"
)

var (
	StartCmd  = &cobra.Command{
		Use:     "test",
		Short:   "用于测试语法的命令",
		Example: "go-api test",
		PreRun: func(cmd *cobra.Command, args []string) {
			 setup()
		},
		RunE: func(cmd *cobra.Command, args []string) error {
			return run()
		},
	}
)

func setup() {
	//1. 读取配置
	configYml := "config/settings.dev.yml"
	config.Setup(configYml)
	//2. 设置日志
	logger.Setup()
	//3. 初始化数据库链接
	database.Setup()

	usageStr := `starting test`
	global.Logger.Debug(usageStr)
}

func run() error {
	defer CountTime(time.Now())

	gorm1()

	return nil
}

func test() {
	defer CountTime(time.Now())
	global.Logger.Info("开始")
	time.Sleep(time.Second * 5)
	global.Logger.Info("结束")
}

// 运行时间计算
func CountTime(startTime time.Time)  {
	// 开始时间
	terminal := time.Since(startTime)
	global.Logger.File("debug").Debugf("运行时间 %v", terminal)
}

func dryrun(){
	db := global.Eloquent
	var user model.Users
	stmt := db.Session(&gorm.Session{DryRun: true}).First(&user, 1).Statement
	global.Logger.Cat("debug").Info(stmt.SQL.String())
}

// todo:连接池

// 钩子测试

//


// 伪删除测试
func del()  {

}

// 多对多预加载
func Association5()  {
	db := global.Eloquent
	var user model.Users
	db.Preload("Languages").Find(&user,5)
	global.Logger.Cat("test").Info(user)
}

// 多对多1： 反向关联
func Association4()  {
	db := global.Eloquent
	var users []model.Users
	var lanuages model.Languages
	db.Find(&lanuages,9)
	db.Model(&lanuages).Association("Users").Find(&users)
	global.Logger.Info(lanuages,users)
}

func Association3(){
	db := global.Eloquent
	var student model.Student
	var book model.Book
	db.Find(&student,1)
	err := db.Model(&student).Association("Book").Find(&book).Error
	global.Logger.Cat("test").Info(student,book,err)
}

// 多对多创建 （关联表自动创建）
func Association2()  {
	db := global.Eloquent
	student3 := model.Student{
		Code: "000003",
		Name: "王五",
		Books: []model.Book{
			{Name: "书籍1"},
			{Name: "书籍2"},
			{Name: "书籍3"},
			{Name: "书籍4"},
		},
	}
	db.Create(&student3)
	db.Save(&student3)
}

// 多对多1
func Association()  {
	db := global.Eloquent
	var user model.Users
	var lanuages []model.Languages
	db.Find(&user,5)
	db.Model(&user).Association("Languages").Find(&lanuages)
	global.Logger.Cat("test").Info(user,lanuages)
}


// 嵌套加载
func Preload3(){
	db := global.Eloquent
	var users model.Users
	db.Preload("Emails.Users").Find(&users)
	global.Logger.Cat("test").Info(users)
}

// 双向引用
func Preload2() {
	db := global.Eloquent
	var address model.Addresses
	db.Preload("User").Find(&address)
	global.Logger.Cat("test").Info(address)
}

// 一对一，一对多示例
func Preload1(){
	db := global.Eloquent
	var user model.Users
	//var addresses []model.Addresses

	//db.Find(&user)
	//db.Model(&user).Association("Addresses").Find(&addresses)

	db.Preload("BillingAddreses").Preload("ShippingAddreses").Preload("Addresses").Preload("Emails").Find(&user)
	global.Logger.Cat("test").Info(user)
}


func gorm1() {
	db := global.Eloquent
	user := model.Users{
		// Uid:  5,
		Name:            "周大刚",
		BillingAddreses:  &model.Addresses{Address1: "Billing Address - 122121212"},
		ShippingAddreses: &model.Addresses{Address1: "Shipping Address - Address 1"},
		Emails:          []*model.Emails{
			{Email: "jinzhu@example.com"},
			{Email: "jinzhu-2@example.com"},
		},
		Languages:       []model.Languages{
			{Name: "中文"},
			{Name: "英文"},
		},
	}
	result := db.Omit("Languages").Create(&user)
	tools.Print(result)
}
