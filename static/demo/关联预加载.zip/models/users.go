package demo

type Users struct {
	Uid int `json:"uid" gorm:"primary_key;AUTO_INCREMENT"`
	Name string `json:"name"`
	BillingAddressId int `json:"billing_address_id"`
	ShippingAddressId int `json:"shipping_address_id"`
	BillingAddreses *Addresses `json:"billing_addreses,omitempty" gorm:"foreignKey:BillingAddressId"`
	ShippingAddreses *Addresses `json:"shipping_addreses,omitempty" gorm:"foreignKey:ShippingAddressId"`
	Addresses []*Addresses `json:"addresses,omitempty" gorm:"foreignKey:Uid;references:Uid"`
	Emails []*Emails `json:"emails" gorm:"foreignKey:Uid;references:Uid"`
	Languages []Languages `json:"languages" gorm:"many2many:user_languages;foreignKey:Uid;joinForeignKey:Uid;JoinReferences:LanguageId;references:Id"`
	DateModel
}
