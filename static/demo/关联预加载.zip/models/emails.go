package demo

type Emails struct {
	Id int `json:"id" gorm:"primary_key;AUTO_INCREMENT"`
	Uid int `json:"uid"`
	Email string `json:"email"`
	Users *Users `json:"users" gorm:"foreignKey:Uid;references:Uid"`
	DateModel
}
