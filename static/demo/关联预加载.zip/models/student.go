package demo

import "gorm.io/gorm"

type Student struct {
	gorm.Model
	Code string
	Name string
	Books []Book `gorm:"many2many:student_books;"`
}
