package demo

import "gorm.io/gorm"

type Book struct {
	gorm.Model
	Name string
	Students []Student `gorm:"many2many:student_books;"`
}
