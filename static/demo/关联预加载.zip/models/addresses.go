package demo

type Addresses struct {
	Id int `json:"id" gorm:"primary_key;AUTO_INCREMENT"`
	Uid int `json:"uid"`
	Address1 string `json:"address_1"`
	User *Users `json:"user" gorm:"foreignKey:Uid;references:Uid"`
	DateModel
}
