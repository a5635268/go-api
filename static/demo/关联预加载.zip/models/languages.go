package demo

type Languages struct {
	Id int `json:"id" gorm:"primary_key;AUTO_INCREMENT"`
	Name string `json:"name"`
	Users []*Users `json:"users" gorm:"many2many:user_languages;foreignKey:Id;joinForeignKey:LanguageId;JoinReferences:Uid;references:Uid"`
	DateModel
}

type UserLanguages struct {
	Uid int `json:"uid"`
	LanguageId int `json:"language_id"`
}
