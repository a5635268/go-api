package main

import "go-api/cmd"

func main() {
	cmd.Execute()
}
