package tools

import "strconv"

func Int64ToString(e int64) string {
	return strconv.FormatInt(e, 10)
}
