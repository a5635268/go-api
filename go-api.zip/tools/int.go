package tools

import "strconv"

func IntToString(e int) string {
	return strconv.Itoa(e)
}
