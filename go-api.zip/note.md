## todo

**脚手架项目**

1. 新建一个脚手架的git项目 [ok]
2. 以go-admin为基础，删除所有多余的代码 [ok]
3. 基于`bee`的热更新 [ok]
4. 错误处理和测试,404捕获 [OK]
5. 日志测试 [ok]
6. 熟悉GORM的关联 [ok]
5. validator的测试和集成 [OK] 
6. redis-map和redis的集成,redis队列测试。[OK]
    1. redisCache集成 [ok]
    2. 测试一下，重新修改源码，让其支持原生写法  [OK]
    3. 队列测试 [OK] 
7. GA高级专题熟悉 [OK]
8. GORM回调配置缓存项 [OK]
8. jwt登录验证 (0.5天，10/22) [OK 1天，10/22]
2. 分拆job命令。（1天，10/28）[OK 0.5天，10/28]
7. 代码部署和运维实战 （4天，10/29-11/1）
    1. Makefile [OK]
    2. 交叉编译 [ok]
    3. 环境部署 [ok]
    2. docker部署 [ing] (如何使用Docker部署Go Web应用)[https://www.liwenzhou.com/posts/Go/how_to_deploy_go_app_using_docker/]
    5. 将Golang应用部署到Docker： https://segmentfault.com/a/1190000013960558
    5. https://gitee.com/mgr9525/gokins
        1. 安装运行 
    1. 基于 GitHub Actions 实现 Golang 项目的自动构建部署: http://blog.haohtml.com/archives/19997
    2. GitHub Actions 入门教程: http://www.ruanyifeng.com/blog/2019/09/getting-started-with-github-actions.html
    3. Golang使用Github Actions CI教程 : https://studygolang.com/articles/23250
    4. #Golang #学习 通过POSTMAN来测试平滑重启
    6. https://syncd.cc/docs/#/    

supervisor配置
~~~

~~~


nginx配置
~~~
server {
    listen       80;
    server_name  go.example.com;

    access_log  /var/log/nginx/go.example.com.access.log  main;

    # 开启debug日志进行配置调试，正式改为warn
    error_log  /var/log/nginx/go.example.com.error.log  debug;
    
    location / {
      proxy_set_header   Host             $http_host;
      proxy_set_header   X-Real-IP        $remote_addr;
      proxy_set_header   X-Forwarded-For  $proxy_add_x_forwarded_for;
      proxy_set_header   X-Forwarded-Proto  $scheme;
      rewrite ^/(.*)$ /$1 break;
      proxy_pass  http://172.28.3.126:8000;
    }
}
~~~

启动脚本
~~~shell script
# !/bin/bash

# 如果是mac使用这个打包
# CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o go-admin main.go

# 如果是windows使用这个打包 自行测试
# SET CGO_ENABLED=0
# SET GOOS=linux
# SET GOARCH=amd64
# go build -o go-admin main.go

# 如果是linux环境使用这个打包
rm -f go-api
go build -o go-api main.go && ./restart.sh
~~~

重启脚本
~~~shell script
#!/bin/bash
echo "删除进程"
killall go-api #杀死运行中的go-api服务进程
echo "启动进程"
sleep 1 #停1秒，由supervisor自动启动后再看进行
# nohup ./go-api server -c=config/settings.yml >> access.log 2>&1 & #后台启动服务将日志写入access.log文件
ps -aux | grep go-api #查看运行用的进程
# netstat -tnlap #查看启动启动情况
~~~


9. 功能集成
> 1. 图片上传,集成oss （1天）
> 3. 微信认证与支付 （1天） 
> 2. API文档生成 
> 4. websocket聊天，ping
> 5. 日志异步邮件发送
> 6. 煎鱼的gin连载： https://segmentfault.com/u/eddycjy/articles?page=3
> 7. go爬虫： https://segmentfault.com/a/1190000014960086
>   1. 
10. 性能调优
    1. https://www.liwenzhou.com/posts/Go/performance_optimisation/
    2. 用 GODEBUG 看 GC https://segmentfault.com/a/1190000020255157
    3. 用 GODEBUG 看调度跟踪 https://segmentfault.com/a/1190000020108079
    4. Golang 大杀器之跟踪剖析 trace https://segmentfault.com/a/1190000019736288
    5. Golang 大杀器之性能剖析 PProf https://segmentfault.com/a/1190000016412013
    6. WSL的断掉调试与cli运行


**扩展**

1. 并发测试
2. nginx-debug 测试： 
    1. https://blog.csdn.net/zhangge3663/article/details/84583526
    2. https://blog.csdn.net/defonds/article/details/11612247

## 待研究

阅读研究： https://my.oschina.net/90design

## go博文系列

1. defer
2. 并发编程
3. 接口
4. 反射
5. 错误

## 其他参考

1. https://studygolang.com/topics/10625

## 代码阅读

### 关键节点

~~~go
// bee run  -runargs="server -c=config/settings.dev.yml"
// gin run 

// 编辑器
// GOPROXY=https://goproxy.io

// 命令注册：cmd/cobra.go:42

// 全局变量： global/adm.go:10

// 全局中间件： router/init.go:29

// 获取配置
// 配置加载： tools/config/config.go:31
viper.GetString("settings.application.mode")

// 组件加载
// tools/config->cmd/api/server.go:54

// 日志使用
global.Logger.Cat(). // File
~~~

### jwt

~~~go
// jwt初始化： server/app/admin/router/initrouter.go:35
// 获取用户信息：server/pkg/jwtauth/jwtauth.go:452
// token的生成： server/pkg/jwtauth/jwtauth.go:446


// 用户身份验证：server/app/admin/middleware/handler/auth.go:59
// 从jwt里面获取数据： server/pkg/jwtauth/jwtauth.go:386
// token，获取途径，header: Authorization, query: token, cookie: jwt
~~~



