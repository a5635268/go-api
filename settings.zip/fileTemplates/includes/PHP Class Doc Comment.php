/**
 * author: xiaogang.zhou@qq.com
 * datetime: ${DATE} ${TIME}
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
    ┏┓      ┏┓
    ┏┛┻━━━┛┻┓
    ┃      ☃      ┃
    ┃  ┳┛  ┗┳  ┃
    ┃      ┻      ┃
    ┗━┓      ┏━┛
    ┃      ┗━━━┓
    ┃  神兽保佑    ┣┓
    ┃　永无BUG！   ┏┛
    ┗┓┓┏━┳┓┏┛
     ┃┫┫  ┃┫┫
     ┗┻┛  ┗┻┛
 */
